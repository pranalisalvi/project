/*********************************************************************
 * File                 : EmpCrudController.java
 * Author Name          : NIKHIL PANDEY
 * Desc                 : JAVA Controller
 * Version              : 1.0
 * Creation Date        : 31-Mar-2017
 * Last Modified Date   : 31-Mar-2017
 *********************************************************************/
package com.capgemini.appl.controlers;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.persistence.RollbackException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import oracle.net.aso.r;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;

import sun.util.logging.resources.logging;

@Controller
public class UniversityCrudController {
	private UniversityService service;
	List<String> designation;
	private List<String> highestQualification;// changed by pooja

	@Resource(name = "universityService")
	public void setEmpServices(UniversityService service) {
		this.service = service;
	}

	@PostConstruct
	public void initialize() {// this method is used to get dropdown list in jsp

		highestQualification = new ArrayList<>();

		highestQualification.add("B.Tech");
		highestQualification.add("BSC");
		highestQualification.add("MSC");
		highestQualification.add("BA");
		highestQualification.add("BCA");
		highestQualification.add("MBA");
		highestQualification.add("M.Tech");
	}

	// ////////////////END///////////////////////////////////////

	// Default Page of Project
	@RequestMapping("index")
	public ModelAndView welcome() {
		ModelAndView model = new ModelAndView("index");
		return model;

	}

	// //////////////////////////////////////////////////////
	@RequestMapping("applicant")
	public ModelAndView applicant() {
		ModelAndView model = new ModelAndView("applicant");
		return model;
	}

	@RequestMapping("showApplicant")
	public ModelAndView showApplicant(HttpSession session) {
		ModelAndView modelAndView = null;

		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "mac") {
				// ///////////////////////////////////////////////////////////////////////////////////
				try {
					System.out.println(session.getAttribute("log").toString());
					List<Application> list = service.showApplications();

					if (list.isEmpty()) {

						modelAndView = new ModelAndView("errorMember");
						modelAndView.addObject("msg",
								"No ApplicantList to Accept or Reject");

					} else {
						modelAndView = new ModelAndView("showApplicant");
						modelAndView.addObject("list", list);
					}
				} catch (UniversityAdmissionException e) {

					modelAndView = new ModelAndView("errorMember");
					modelAndView.addObject("msg", "Can not accept Application");
				}

			} else {
				System.out
						.println(session.getAttribute("log").toString() + "1");
				ModelAndView model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}

			// ////////////////////////////////////////////////
		}

		catch (Exception e) {

			ModelAndView model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		// //////////////////////////////////////////
		return modelAndView;

	}

	@RequestMapping("giveInterview")
	public ModelAndView giveInterview(
			@RequestParam("applicant") int applicationId, ModelAndView model,
			HttpSession session) {

		System.out.println(session.getAttribute("log").toString());
		if (session.getAttribute("log").toString() == "mac") {
			try {
				Application application = service
						.getApplicantDetails(applicationId);
				model.addObject("Application", application);
				model.setViewName("interviewDate");
			} catch (UniversityAdmissionException e) {
				model = new ModelAndView("error");
				model.addObject("msg", "Can not accept Application");
			}
		}

		return model;

	}

	@RequestMapping("accept")
	public ModelAndView accept(@ModelAttribute Application application,
			BindingResult result, HttpSession session) {
		ModelAndView modelAndView = null;
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "mac") {

				try {

					Application application2 = service
							.getApplicantDetails(application.getApplicationId());
					application2.setDateOfInterview(application
							.getDateOfInterview());
					application2.setStatus("accepted");
					boolean success = service
							.acceptOrRejectApplication(application2);

					if (success) {
						List<Application> list = service.showApplications();

						if (list.isEmpty()) {

							modelAndView = new ModelAndView("errorMember");
							modelAndView.addObject("msg",
									"No ApplicantList to Accept or Reject");

						} else {
							modelAndView = new ModelAndView("showApplicant");
							modelAndView.addObject("list", list);
						}

					} else {
						modelAndView = new ModelAndView("error");
						modelAndView.addObject("msg",
								"Can not accept Application");
					}
				} catch (UniversityAdmissionException e) {
					modelAndView = new ModelAndView("error");
					modelAndView.addObject("msg", "Can not accept Application");
				}
			} else {
				System.out
						.println(session.getAttribute("log").toString() + "1");
				ModelAndView model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}
		} catch (Exception e) {

			ModelAndView model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return modelAndView;
	}

	@RequestMapping("reject")
	public ModelAndView reject(@RequestParam("applicant") int applicationId,
			HttpSession session) {
		ModelAndView modelAndView = null;

		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "mac") {
				try {

					Application application2 = service
							.getApplicantDetails(applicationId);
					// application2.setDateOfInterview(application.getDateOfInterview());
					application2.setStatus("rejected");
					boolean success = service
							.acceptOrRejectApplication(application2);

					if (success) {
						List<Application> list = service.showApplications();
						modelAndView = new ModelAndView("showApplicant");
						modelAndView.addObject("list", list);
					} else {
						modelAndView = new ModelAndView("error");
						modelAndView.addObject("msg",
								"Can not accept Application");
					}
				} catch (UniversityAdmissionException e) {
					modelAndView = new ModelAndView("error");
					modelAndView.addObject("msg", "Can not accept Application");
				}
			} else {
				System.out
						.println(session.getAttribute("log").toString() + "1");
				ModelAndView model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}
		} catch (Exception e) {

			ModelAndView model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}

		return modelAndView;
	}

	// ///////////////////////////////////////////////
	/*
	 * //show List of Employee
	 * 
	 * @RequestMapping("showAllEmps") public ModelAndView showAllEmps() {
	 * ModelAndView model = null; try { List<Emp> list = service.getAllEmps();
	 * model = new ModelAndView("showAllEmps"); model.addObject("list", list); }
	 * catch (EmpEcxeption e) { model = new ModelAndView("error");
	 * model.addObject("msg", e); } return model; }
	 * 
	 * //Navigate to New Employee Entry Form
	 * 
	 * @RequestMapping("addNewEmp") public ModelAndView addNew(ModelAndView
	 * model) {
	 * 
	 * Emp emp = new Emp(); model.addObject("emp", emp);
	 * model.addObject("designation", designation);
	 * model.setViewName("addNewEmp"); return model;
	 * 
	 * }
	 * 
	 * //Add Employee to Database Or Show error
	 * 
	 * @RequestMapping("addEmp") public ModelAndView addEmp(@ModelAttribute
	 * 
	 * @Valid Emp emp, BindingResult result) { ModelAndView model = new
	 * ModelAndView(); if (result.hasErrors()) { model.addObject("emp", emp);
	 * model.addObject("designation", designation);
	 * model.setViewName("addNewEmp"); return model; }
	 * 
	 * try { Emp myemp = service.insertNewEmp(emp); model.addObject("emp",
	 * myemp); model.setViewName("successEmp"); return model; } catch
	 * (EmpEcxeption e) { model.setViewName("error"); model.addObject("msg", e);
	 * return model; }
	 * 
	 * }
	 */
	// ///////////////////////////// amruta
	// /////////////////////////////////////////

	/*
	 * @RequestMapping("enterUserName") public ModelAndView enterUserName(){
	 * System.out.println("In controlling method"); ModelAndView model = new
	 * ModelAndView("enterUserName"); return model; }
	 */

	/*
	 * @RequestMapping("getUserDetail") public ModelAndView
	 * getUserDetail(@RequestParam String userName) {
	 * 
	 * System.out.println("In controlling method" + userName);
	 * 
	 * Users users; ModelAndView model = null; try { users =
	 * service.getUserDetail( userName); model = new
	 * ModelAndView("traineeDetails"); model.addObject("userDetail",users); }
	 * catch (UniversityAdmissionException e) { model = new
	 * ModelAndView("error"); model.addObject("msg",e.getMessage()); }
	 * 
	 * 
	 * return model; }
	 */

	@RequestMapping("/showAllApplicantsDetail.do")
	public ModelAndView showAllApplicantsDetail(HttpSession session) {
		ModelAndView model = null;
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "mac") {

				try {
					List<Application> appl = service
							.getApplicationOnSheduledId(null);
					model = new ModelAndView("showAllApplicantsDetail");
					model.addObject("appl", appl);
				} catch (UniversityAdmissionException e) {
					model = new ModelAndView("error");
					model.addObject("msg", "Can not show Application Details");
				}
			} else {
				System.out
						.println(session.getAttribute("log").toString() + "1");
				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return model;
	}

	@RequestMapping("login")
	public ModelAndView getLoginPage() {

		ModelAndView model = new ModelAndView("login");
		model.addObject("user", new Users());
		return model;

	}

	// HttpServletRequest request,HttpSession session
	@RequestMapping("/authenticate.do")
	public ModelAndView authenticate(@ModelAttribute @Valid Users user,
			BindingResult result, HttpSession session) {
		ModelAndView model = new ModelAndView();
		try {
			System.out.println(user.getLoginId() + " " + user.getPassword());
			try {
				Users u = service.getUserDetail(user.getLoginId());
				String password = u.getPassword();
				if (password.equals(user.getPassword())) {
					String role = u.getRole();
					System.out.println("role" + role);
					if (role.equals("mac")) {
						session.setAttribute("log", "mac");
						/*
						 * HttpSession log = request.getSession(true);
						 * log.setAttribute("logRight", role);
						 */
						System.out.println(role);
						model = new ModelAndView("member");
					}

					else if (role.equals("admin")) {
						session.setAttribute("log", "admin");
						model = new ModelAndView("admin");

					}

					else {
						model = new ModelAndView("login");
						model.addObject("msg",
								"Not Authorized person of administrator or members of admission committee");
						model.addObject("user", new Users());
					}

				} else {
					model = new ModelAndView("login");
					model.addObject("msg",
							"Not Authorized person of administrator or members of admission committee");

					model.addObject("user", new Users());
				}
			} catch (UniversityAdmissionException e) {
				model = new ModelAndView("error");
				model.addObject("msg", "Can not accept Application");
			}

			return model;
		} catch (Exception e) {
			model = new ModelAndView("login");
			model.addObject("msg",
					"Not Authorized person of administrator or members of admission committee");

			model.addObject("user", new Users());
			return model;
		}

	}

	@RequestMapping("logOut")
	public ModelAndView logOut(HttpSession session) {
		ModelAndView model = null;

		session.invalidate();
		model = new ModelAndView("index");

		return model;

	}

	// ///////////////////////////////////////////////
	// //////////////////////////////////////////////////////changed by
	// Pooja///////////////////

	@RequestMapping("showDetailsProgram")
	public ModelAndView showAllProgramOffered() {
		ModelAndView model = null;
		try {
			List<ProgramsOffered> list = service.showAll();
			model = new ModelAndView("programInformation");
			model.addObject("data", list);
		} catch (UniversityAdmissionException e) {
			model = new ModelAndView();
			model.setViewName("error");
			model.addObject("msg", "Failed to show program offered");
			e.printStackTrace();
		}
		return model;

	}

	@RequestMapping("getScheduleProgram")
	public ModelAndView showScheduleProgram(@RequestParam String id) {
		ModelAndView model = new ModelAndView();
		try {
			List<ProgramsScheduled> list = service.getAllProgramSheduled(id);
			model = new ModelAndView("sheduledDetailsForApply");
			model.addObject("list", list);
		} catch (UniversityAdmissionException e) {
			model.setViewName("error");
			model.addObject("msg", "Failed to show Scheduled Program:");

		}
		return model;

	}

	@RequestMapping("applicantEntryForm")
	public ModelAndView getApplicationForm(@RequestParam int id) {
		ModelAndView model = null;

		model = new ModelAndView("application");
		Application application = new Application();
		ProgramsScheduled programsScheduled = new ProgramsScheduled();
		try {
			programsScheduled = service.getProgramsScheduled(id);

			application.setScheduled(programsScheduled);
			application.setStatus("applied");
			model.addObject("application1", application);
			model.addObject("id", id);

			model.addObject("qualification", highestQualification);
		} catch (UniversityAdmissionException e) {
			model = new ModelAndView("error");
			model.addObject("msg", "Can not accept Application");
		}

		return model;
	}

	@RequestMapping("addApplicant")
	public ModelAndView addApplicantDetails(
			@ModelAttribute("application1") @Valid Application application,
			BindingResult result) {

		ModelAndView model = new ModelAndView();

		if (result.hasErrors()) {

			model.setViewName("application");

			model.addObject("application1", application);
			model.addObject("qualification", highestQualification);
			return model;
		}

		try {

			int applicationId = service.addApplicant(application);

			System.out.println(applicationId);
			model.setViewName("success");
			model.addObject("applicationId", applicationId);
		} catch (UniversityAdmissionException e) {
			model.setViewName("error");
			model.addObject("msg", "Record Insertion failed:");
		}
		return model;
	}

	// /////////////////////////////////////////////////////////END/////////////////////////////////////////////
	// ///////////////////////////////////////////////Nehali

	@RequestMapping("ProgramOffered")
	public ModelAndView showAllProgramDetails(HttpSession session) {
		ModelAndView modelAndView = null;
		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				String msg;
				try {
					List<ProgramsOffered> programmList = service
							.getAllProgramDetails();

					if (programmList.isEmpty()) {
						msg = "Program Details Not exists";
						modelAndView = new ModelAndView("errorAdmin");
						modelAndView.addObject("msg", msg);

					} else {

						System.out.println("hi" + programmList);
						modelAndView = new ModelAndView("showAllProgramsDetail");
						modelAndView.addObject("programList", programmList);

					}
				} catch (UniversityAdmissionException e) {
					modelAndView = new ModelAndView();
					modelAndView.setViewName("errorAdmin");
					modelAndView.addObject("msg", "Program Updation failed: "
							+ e.getMessage());
					return modelAndView;
				}

			} else {

				modelAndView = new ModelAndView("login");
				modelAndView.addObject("user", new Users());
				return modelAndView;
			}

		} catch (Exception e) {

			modelAndView = new ModelAndView("login");
			modelAndView.addObject("user", new Users());
			return modelAndView;
		}

		return modelAndView;
	}

	@RequestMapping("addShedule")
	public ModelAndView submitEntryForm(@RequestParam("id") String programName,
			HttpSession session) {
		ModelAndView modelAndView = null;

		modelAndView = new ModelAndView("addScheduleDetails");
		modelAndView.addObject("data", programName);
		modelAndView.addObject("schedule", new ProgramsScheduled());
		return modelAndView;
	}

	@RequestMapping("insertScheduleDetail")
	public ModelAndView submitScheduleDetail(
			@ModelAttribute("schedule") @Valid ProgramsScheduled schedule,
			BindingResult result, HttpSession session) {
		System.out.println("insertScheduleDetail");
		String msg;
		System.out.println(schedule);
		ModelAndView modelAndView = null;

		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				System.out.println(result.getAllErrors());
				System.out.println(result);
				System.out.println(result.hasErrors());

				if (result.hasErrors()) {
					System.out.println(schedule.getProgram().getProgramName());

					modelAndView = new ModelAndView("addScheduleDetails");
					modelAndView.addObject("data", schedule.getProgram()
							.getProgramName());
					modelAndView.addObject("schedule", schedule);

				} else {

					System.out.println(schedule);
					Location loc = new Location();
					loc.setCity(schedule.getLocation().getCity());
					loc.sethState(schedule.getLocation().gethState());
					loc.setZip(schedule.getLocation().getZip());
					String locationId = null;
					System.out.println(loc);

					try {
						System.out.println(loc);

						/*
						 * ProgramsScheduled
						 * programSchedule=service.insertScheduledDetails
						 * (schedule); System.out.println(programSchedule);
						 */
						String startdate = schedule.getStartDate().toString();
						String endDate = schedule.getEndDate().toString();
						Boolean checkDateBoolean = false;
						SimpleDateFormat sdf1 = new SimpleDateFormat(
								"yyyy-MM-dd");
						java.util.Date dateStart;
						java.util.Date dateEnd;

						dateStart = sdf1.parse(startdate);
						dateEnd = sdf1.parse(endDate);

						java.sql.Date sqlStartDate = new Date(
								dateStart.getTime());
						java.sql.Date sqlEndDate = new Date(dateEnd.getTime());
						System.out.println("date" + sqlStartDate + " "
								+ sqlEndDate);

						System.out.println(sqlStartDate.compareTo(sqlEndDate));

						if (sqlStartDate.compareTo(sqlEndDate) < 0) {
							checkDateBoolean = true;

						} else if (sqlStartDate.toString().trim()
								.equals(sqlEndDate.toString().trim())) {
							checkDateBoolean = true;

						} else if (sqlStartDate.compareTo(sqlEndDate) > 0) {
							checkDateBoolean = false;
						}

						System.out.println("date" + checkDateBoolean);
						if (checkDateBoolean) {
							schedule.setStartDate(sqlStartDate);
							schedule.setEndDate(sqlEndDate);

							System.out.println("In con" + schedule);
							ProgramsScheduled programSchedule = service
									.insertScheduledDetails(schedule);
							System.out.println("Insertion result"
									+ programSchedule);

							msg = "Schedule Detail inserted Successfully";
							modelAndView = new ModelAndView("admin");
							modelAndView.addObject("msg", msg);

						} else {

							msg = "Please Enter Correct Date";
							modelAndView = new ModelAndView("errorAdmin");
							modelAndView.addObject("msg", msg);
						}
					} catch (ParseException e) {
						msg = "Location Detail Not Inserted";
						modelAndView = new ModelAndView("errorAdmin");
						modelAndView.addObject("msg", msg);
						System.out.println(e);

					} catch (UniversityAdmissionException e) {
						msg = "Location Detail Not Inserted";
						modelAndView = new ModelAndView("errorAdmin");
						modelAndView.addObject("msg", msg);
						System.out.println(e);
					}

				}
			} else {

				modelAndView = new ModelAndView("login");
				modelAndView.addObject("user", new Users());
				return modelAndView;
			}
		} catch (Exception e) {

			modelAndView = new ModelAndView("login");
			modelAndView.addObject("user", new Users());
			return modelAndView;
		}
		return modelAndView;

	}

	@RequestMapping("ProgramScheduled")
	public ModelAndView showProgramScheduled(HttpSession session) {
		ModelAndView modelAndView = null;
		String msg;
		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				System.out.println("ProgramScheduled");
				List<ProgramsScheduled> scheduleList = new ArrayList<ProgramsScheduled>();
				try {
					scheduleList = service.getAllProgramSheduled();
					System.out.println("Schedule" + scheduleList);

					if (scheduleList.isEmpty()) {
						msg = "Schedule Detail Not exists";
						modelAndView = new ModelAndView("errorAdmin");
						modelAndView.addObject("msg", msg);

					} else {

						System.out.println("hi" + scheduleList);

						modelAndView = new ModelAndView(
								"showAllScheduleForDelete");
						modelAndView.addObject("data", scheduleList);
					}

				} catch (UniversityAdmissionException e) {
					msg = "Schedule Detail Not exists";
					modelAndView = new ModelAndView("errorAdmin");
					modelAndView.addObject("msg", msg);
				}

			}

			else {

				modelAndView = new ModelAndView("login");
				modelAndView.addObject("user", new Users());
				return modelAndView;
			}
		}

		catch (Exception e) {

			modelAndView = new ModelAndView("login");
			modelAndView.addObject("user", new Users());
			return modelAndView;
		}

		return modelAndView;

	}

	@RequestMapping("showAllScheduleForDelete")
	public ModelAndView showProgramScheduled(
			@RequestParam("id") int scheduleId, HttpSession session) {
		ModelAndView modelAndView = null;
		String msg;
		System.out.println(scheduleId);

		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {
				try {
					ProgramsScheduled programSchedule = service
							.deleteSchedule(scheduleId);

					msg = "Schedule Detail Deleted";
					modelAndView = new ModelAndView("admin");
					modelAndView.addObject("msg", msg);

				} catch (UniversityAdmissionException e) {
					// TODO Auto-generated catch block
					msg = "Deletion of Schedule Failed";
					modelAndView = new ModelAndView("errorAdmin");
					modelAndView.addObject("msg", msg);

				}
			} else {

				modelAndView = new ModelAndView("login");
				modelAndView.addObject("user", new Users());
				return modelAndView;
			}
		} catch (Exception e) {

			modelAndView = new ModelAndView("login");
			modelAndView.addObject("user", new Users());
			return modelAndView;
		}

		return modelAndView;

	}

	// //////////////////////////////////////jaini
	@RequestMapping("showAllProgram")
	public ModelAndView showAllPrograms(HttpSession session) {
		ModelAndView model = null;
		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				try {
					model = new ModelAndView("showAllProgram");
					List<ProgramsOffered> list = service.showProgramsOffereds();
					model.addObject("list", list);
				} catch (UniversityAdmissionException e) {
					model = new ModelAndView("errorAdmin");
					model.addObject("msg", e.getMessage());
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}

		}

		catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return model;

	}

	@RequestMapping("showAddProgram")
	public ModelAndView getEntryForm(HttpSession session) {
		ModelAndView model = null;
		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				model = new ModelAndView("addProgram");
				model.addObject("program", new ProgramsOffered());
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}

		}

		catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return model;
	}

	@RequestMapping("/submitAddProgram.do")
	public ModelAndView submitEntryForm(
			@ModelAttribute("program") @Valid ProgramsOffered program,
			BindingResult result, HttpSession session) {
		ModelAndView model = new ModelAndView();
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				if (result.hasErrors()) {
					model.addObject("program", program);
					model.setViewName("addProgram");
					return model;
				}
				try {
					ProgramsOffered programOffered = service
							.addProgram(program);

					if (programOffered != null) {

						model = new ModelAndView("showAllProgram");
						List<ProgramsOffered> list = service
								.showProgramsOffereds();
						model.addObject("list", list);
					}

				} catch (UniversityAdmissionException e) {
					model.setViewName("errorAdmin");
					model.addObject("msg",
							"Record insertion failed: " + e.getMessage());
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}

		return model;
	}

	@RequestMapping("delteProgram")
	public ModelAndView delteProgram(
			@RequestParam("ProgramName") String ProgramName, HttpSession session) {
		ModelAndView model = new ModelAndView();
		// model.addObject("program", new ProgramsOffered());
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {
				List<ProgramsOffered> list;
				try {

					ProgramsOffered p = new ProgramsOffered();
					p.setProgramName(ProgramName);
					service.deleteProgram(p);
					model = new ModelAndView("showAllProgram");
					list = service.showProgramsOffereds();
					model.addObject("list", list);
				} catch (UniversityAdmissionException e) {
					model.setViewName("errorAdmin");
					model.addObject("msg",
							"Record deletion failed: " + e.getMessage());
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return model;
	}

	@RequestMapping("updateProgram")
	public ModelAndView updateProgram(
			@RequestParam("ProgramName") String ProgramName, HttpSession session) {
		ModelAndView model = new ModelAndView();
		// model.addObject("program", new ProgramsOffered());
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {
				System.out.println("xxxxxxxxxxxxxxxx");
				ProgramsOffered programsOffered = new ProgramsOffered();
				programsOffered.setProgramName(ProgramName);
				System.out.println("xxxxxxxxxxxxxxxx");
				try {
					System.out.println("xxxxxxxxxxxxxxxx");
					programsOffered = service.getProgram(programsOffered);
					System.out.println("xxxxxxxxxxxxxxxx");
					model = new ModelAndView("showProgram");
					model.addObject("programsOffered", programsOffered);
				} catch (RollbackException | UniversityAdmissionException e) {
					model.setViewName("errorAdmin");
					model.addObject("msg",
							"Program Updation failed: " + e.getMessage());
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return model;
	}

	@RequestMapping("updateOneProgram")
	public ModelAndView updateOneProgram(
			@ModelAttribute("programsOffered") @Valid ProgramsOffered program,
			BindingResult result, HttpSession session) {
		ModelAndView model = new ModelAndView();
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				if (result.hasErrors()) {

					// ProgramsOffered programsOffered = new ProgramsOffered();
					// programsOffered.setProgramName(program.getProgramName());
					model.addObject("programsOffered", program);
					model.setViewName("showProgram");
					return model;
				}
				try {
					ProgramsOffered programOffered = new ProgramsOffered();
					programOffered = service.updateProgram(program);

					if (programOffered != null) {
						model = new ModelAndView("showAllProgram");
						List<ProgramsOffered> list = service
								.showProgramsOffereds();
						model.addObject("list", list);
					}

				} catch (UniversityAdmissionException e) {
					model.setViewName("errorAdmin");
					model.addObject("msg", "Updation of one program failed: "
							+ e.getMessage());
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;
			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return model;
	}

	// //////////////////////////////////////////////////////pranali
	@RequestMapping("showProgramReport")
	public ModelAndView showProgramReport(ModelAndView model,
			HttpSession session) {

		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				model.setViewName("programReport");
				model.addObject("scheduled", new ProgramsScheduled());
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;

			}
		}

		catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return model;

	}

	@RequestMapping("programReport")
	public ModelAndView submitEntryForm(
			@ModelAttribute("scheduled") ProgramsScheduled scheduled,
			BindingResult result, HttpSession session) {

		ModelAndView model = new ModelAndView();
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				if (result.hasErrors()) {
					System.out.println(result.getAllErrors());
					model.setViewName("programReport");

					model.addObject("scheduled", scheduled);
					return model;
				}
				try {

					List<ProgramsScheduled> scheduledResponse = service
							.showProgramInfo(scheduled);
					if (scheduledResponse.isEmpty()) {
						model = new ModelAndView("programReport");
						model.addObject("msg", "Please Enter Valid Data");
						return model;
					}
					model.setViewName("programInfo");
					model.addObject("programinfo", scheduledResponse);
				} catch (UniversityAdmissionException e) {
					model = new ModelAndView("errorAdmin");
					model.addObject("msg", "Show Failed: ");

				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());
				return model;

			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());
			return model;
		}
		return model;
	}

	@RequestMapping("/loadViewstatus.do")
	public ModelAndView enterApplicantNo() {
		System.out.println("In Controlling method");
		ModelAndView model = new ModelAndView("viewStatus");

		return model;
	}

	// serch by no.
	@RequestMapping("/viewStatus.do")
	public ModelAndView getTraineeDetails(
			@RequestParam("applicationId") @Valid int applicationId,
			HttpSession session) {

		System.out.println("In Controlling method" + applicationId);
		String logString = (String) session.getAttribute("log");
		System.out.println(logString);
		ModelAndView model;
		try {
			Application app = service.showStatus(applicationId);
			if (app == null) {
				model = new ModelAndView("viewStatus");
				model.addObject("msg", "Applicant not found");
				return model;
			}
			model = new ModelAndView("status");
			model.addObject("status", app);
		} catch (UniversityAdmissionException e) {
			model = new ModelAndView("error");
			model.addObject("msg", "Unable to Show Status");
		}

		return model;

	}

	// ////////////////////////////////////////////////////////////////////
	// //////////////////////////rithika//////////////////
	@RequestMapping("/showProgramScheduled.do")
	public ModelAndView listAllPrgrmsScheduled(HttpSession session) {

		System.out.println("In listAllPrgrmsScheduled");
		ModelAndView model = null;

		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				try {
					List<ProgramsScheduled> prgmScheduled = service
							.getAllProgramSheduled();
					System.out.println("Controller" + prgmScheduled);
					if (prgmScheduled.isEmpty()) {

						model = new ModelAndView("errorAdmin");
						model.addObject("msg", "No ProgramScheduledList");

					}

					else {
						model = new ModelAndView("candidateReport");

						model.addObject("data", prgmScheduled);
					}
				} catch (Exception e) {
					model = new ModelAndView("errorAdmin");
					model.addObject("msg",
							"No Applicants for this ScheduledProgramId");
				}

			}

			else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());

			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());

		}

		return model;
	}

	@RequestMapping("/statusReport.do")
	public ModelAndView viewApplicantList(@RequestParam("id") int sProgramId,
			HttpSession session) {

		// int sProgramId=Integer.parseInt(asProgramId);
		System.out.println("In Controller viewApplicantList1" + sProgramId);
		ModelAndView model = null;
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "admin") {

				try {
					List<Application> applicationList = service
							.showApplicantInfo(sProgramId);
					System.out.println("In Controller viewApplicantList2"
							+ applicationList);
					if (applicationList == null || applicationList.isEmpty()) {

						model = new ModelAndView("errorAdmin");
						model.addObject("msg",
								"No Applicants for this ScheduledProgramId");

					} else {
						model = new ModelAndView("candidateInfo");
						model.addObject("applicantinfo", applicationList);
					}

				} catch (UniversityAdmissionException e) {
					model = new ModelAndView("errorAdmin");
					model.addObject("msg",
							"No Applicants for this ScheduledProgramId");
					e.printStackTrace();
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());

			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());

		}
		return model;

	}

	@RequestMapping("/takeInterview.do")
	public ModelAndView takeInterview(HttpSession session) {

		ModelAndView model = null;

		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "mac") {

				try {
					List<ProgramsScheduled> pScheduleList = service
							.getAllProgramSheduled();
					System.out.println("In Controller takeInterview"
							+ pScheduleList);
					model = new ModelAndView("showSheduleDetail");
					model.addObject("data", pScheduleList);

				} catch (UniversityAdmissionException e) {
					model = new ModelAndView("errorMember");
					model.addObject("msg", "Can not accept Application");
				}

			}
		}

		catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());

		}

		return model;

	}

	@RequestMapping("/retriveApplication.do")
	public ModelAndView retriveApplication(@RequestParam("id") int appId,
			HttpSession session) {
		System.out.println("In ControllerretriveApplication:" + appId);
		ModelAndView model = null;

		try {

			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "mac") {
				try {
					List<Application> applicationList = service
							.getApplicationOnSheduledId(appId);
					if (applicationList.isEmpty()) {

						model = new ModelAndView("errorMember");
						model.addObject("msg", "No accepted Applicant");

					} else {
						model = new ModelAndView("showAllApplicantsDetail");
						model.addObject("data", applicationList);
					}

				} catch (UniversityAdmissionException e) {
					model = new ModelAndView("errorMember");
					model.addObject("msg", "No accepted Applicant");
					// e.printStackTrace();
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());

			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());

		}
		return model;
	}

	@RequestMapping("/confirmed.do")
	public ModelAndView updateApplicationsConfirmed(
			@RequestParam("id") int appId, HttpSession session) {

		System.out
				.println("In Controller updateApplicationsConfirmed:" + appId);

		ModelAndView model = null;
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "mac") {
				String status = "confirmed";

				try {
					boolean update = service.updateApplicationDB(appId, status);
					if (update == true) {

						List<ProgramsScheduled> schedule = service
								.getAllProgramSheduled();
						model = new ModelAndView("showSheduleDetail");
						model.addObject("data", schedule);
					} else {

						model = new ModelAndView("errorMember");
						model.addObject("msg", "Unable to Confirm Application");
					}
				} catch (UniversityAdmissionException e) {
					model = new ModelAndView("errorMember");
					model.addObject("msg", "Unable to Confirm Application");
					e.printStackTrace();
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());

			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());

		}
		return model;

	}

	@RequestMapping("/rejectCandidate.do")
	public ModelAndView updateApplicationsRejected(
			@RequestParam("id") int appId, HttpSession session) {

		System.out.println("In Controller updateApplicationsRejected:" + appId);
		ModelAndView model = null;
		try {
			System.out.println(session.getAttribute("log").toString());
			if (session.getAttribute("log").toString() == "mac") {
				String status = "rejected";

				try {
					boolean update = service.updateApplicationDB(appId, status);
					if (update == true) {

						List<ProgramsScheduled> schedule = service
								.getAllProgramSheduled();
						model = new ModelAndView("showSheduleDetail");
						model.addObject("data", schedule);
					} else {

						model = new ModelAndView("errorMember");
						model.addObject("msg", "Unable to reject Application");
					}
				} catch (UniversityAdmissionException e) {
					model = new ModelAndView("errorMember");
					model.addObject("msg", "Unable to reject Application");
					// e.printStackTrace();
				}
			} else {

				model = new ModelAndView("login");
				model.addObject("user", new Users());

			}
		} catch (Exception e) {

			model = new ModelAndView("login");
			model.addObject("user", new Users());

		}
		return model;
	}

}
