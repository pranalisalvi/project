package com.capgemini.appl.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;

@Repository("universityDao")
public class UniversityDaoImpl implements UniversityDao {

	@PersistenceContext
	private EntityManager manager;

	// ///////////////////////////////////////////////////////////
	@Override
	public List<Application> showApplications()
			throws UniversityAdmissionException {
		Query query = manager.createNamedQuery("qryAllApplApplied",
				Application.class);
		// Query query = manager.createQuery("select e from Application e");
		// //("select e from APPLICATION e", Application.class);

		return query.getResultList();
	}

	// //////////////////////////////////////////////////AMRUTA
	@Override
	public List<Application> getApplicationOnSheduledId(String ScheduleId)
			throws UniversityAdmissionException {

		Query qry = manager.createNamedQuery("qryAllAppl", Application.class);
		return qry.getResultList();

	}

	@Override
	public Users getUserDetail(String userName)
			throws UniversityAdmissionException {
		// EntityManager manager = factory.createEntityManager();
		Users users = manager.find(Users.class, userName);
		return users;

	}

	// ////////////////////////////////////////////////////
	// /////////////////////////////////////////////////Pooja
	@Override
	public List<ProgramsOffered> showAll() throws UniversityAdmissionException {
		Query query = manager.createNamedQuery("qryAllProgramOffered",
				ProgramsOffered.class);
		return query.getResultList();
	}

	@Override
	public List<ProgramsScheduled> getAllProgramSheduled(String programName)
			throws UniversityAdmissionException {

		Query qry = manager.createNamedQuery("qryProgramsScheduled",
				ProgramsScheduled.class);
		qry.setParameter("pName", programName);

		return qry.getResultList();

	}

	@Override
	public int addApplicant(Application appl)
			throws UniversityAdmissionException {
		System.out.println("Dsfsdgdrgdrgdrg");
		// System.out.println();
		ProgramsScheduled p = manager.find(ProgramsScheduled.class, appl
				.getScheduled().getScheduledProgramId());
		appl.setScheduled(p);
		appl.setStatus("applied");
		System.out.println(appl);
		manager.persist(appl);
		System.out.println("Successfully Inserted");
		return appl.getApplicationId();
	}

	// //////////////////////////////////////////////////
	// /////////////////////////////////////////////////////////////Nehali

	@Override
	public List<ProgramsOffered> getAllProgramDetails()
			throws UniversityAdmissionException {
		Query query = manager.createNamedQuery("qryAllProgramOffered",
				ProgramsOffered.class);
		return query.getResultList();
	}

	@Override
	public Location insertLocationDetails(Location loc)
			throws UniversityAdmissionException {

		manager.persist(loc);
		return loc;
	}

	@Override
	public ProgramsScheduled insertScheduledDetails(ProgramsScheduled schedule)
			throws UniversityAdmissionException {
		ProgramsOffered p = manager.find(ProgramsOffered.class, schedule
				.getProgram().getProgramName());
		schedule.setProgram(p);
		System.out.println(schedule);
		manager.persist(schedule);
		return schedule;

	}



	@Override
	public ProgramsScheduled deleteSchedule(int id)
			throws UniversityAdmissionException {
		try {
			ProgramsScheduled schedule = manager.find(ProgramsScheduled.class,
					id);
			if (schedule == null) {
				throw new UniversityAdmissionException(
						"ProgramsScheduled Id does Not Exists");

			}
			schedule.setProgram(null);
			manager.remove(schedule);
			return schedule;
		} catch (RollbackException e) {

			//e.printStackTrace();
			throw new UniversityAdmissionException("Failed deletion", e);
		}
	}

	// /////////////////////////////////////////////////////////////////////////////////////

	@Override
	public Application getApplicantDetails(int applicationId)
			throws UniversityAdmissionException {
		Application application = manager
				.find(Application.class, applicationId);
		return application;
	}

	

	
	@Override
	public boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException {
		System.out.println(application);
		manager.merge(application);
		return true;
	}


	
	@Override
	public List<Application> showApplicantInfo(int id)
			throws UniversityAdmissionException {
		try {
			System.out.println("in showApplicantInfo");
			TypedQuery<Application> qry =manager.createNamedQuery("qryAllApplId",Application.class);
			qry.setParameter("prgrmId",id);
			List<Application> applicationList =qry.getResultList();
			System.out.println("AppList"+applicationList);
			return applicationList;
		} catch (Exception e) {
			throw new UniversityAdmissionException("Improper qry Fabrication",e);
			//e.printStackTrace();
		}
	}

	@Override
	public int getApplicationId() throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}

	
	@Override
	public int getProgramId(String programName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String isUserAuthanticate(String userName, String password)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public ProgramsScheduled getProgramsScheduled(int id)
			throws UniversityAdmissionException {

		ProgramsScheduled programsScheduled = manager.find(
				ProgramsScheduled.class, id);
		System.out.println("get dao" + programsScheduled);
		return programsScheduled;
	}

	
	@Override
	public ProgramsOffered addProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException {
		
		try {
			
			manager.persist(p);
			
		} catch (RollbackException e) {
		
			throw new UniversityAdmissionException("Record not inserted",e);
		}
		return p;
		
	}

	@Override
	public ProgramsOffered updateProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException {

			manager.merge(p);
		
		
		return p;
	} 
	

	@Override
	public ProgramsOffered deleteProgram(ProgramsOffered p) throws UniversityAdmissionException, RollbackException {
			
				ProgramsOffered programsOffered=manager.find(ProgramsOffered.class,p.getProgramName());
				
				manager.remove(programsOffered);
		
		
		return p;
	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException {
		Query query=manager.createNamedQuery("qryAllProgramsOffered", ProgramsOffered.class);
		return query.getResultList();
	}

	@Override
	public ProgramsOffered getProgram(ProgramsOffered p)
			throws UniversityAdmissionException, RollbackException {
		
		ProgramsOffered programsOffered=manager.find(ProgramsOffered.class, p.getProgramName());
		return programsOffered;
	}
	
	///////////////////////////////////////////////////
	@Override
	public List<ProgramsScheduled> showProgramInfo(ProgramsScheduled scheduled)
			throws UniversityAdmissionException {
		Query qry=manager.createNamedQuery("qryScheduled", ProgramsScheduled.class);
		qry.setParameter("sdate", scheduled.getStartDate());
		qry.setParameter("ndate", scheduled.getEndDate());
		
		return qry.getResultList();
		
	}
	
	@Override
	public Application showStatus(int applicationId)
			throws UniversityAdmissionException {
		Application app= manager.find(Application.class, applicationId);
		
		return app;
		
	}
	
	@Override
	public List<ProgramsScheduled> getAllProgramSheduled()
			throws UniversityAdmissionException {
		try {
			TypedQuery<ProgramsScheduled> qry=manager.createNamedQuery("qryAllPrgrmScheduled",ProgramsScheduled.class);
			List<ProgramsScheduled> prgmScheduledList =qry.getResultList();
			return prgmScheduledList;
		} catch (Exception e) {
			throw new UniversityAdmissionException("Improper qry Fabrication",e);
			
		}
	
	}

	@Override
	public List<Application> getApplicationOnSheduledId(int ScheduleId)
			throws UniversityAdmissionException {
		System.out.println("in DaoImpl  getApplicationOnSheduledId");
		try {
			TypedQuery<Application> qry=manager.createNamedQuery("qryAllAppDetail",Application.class);
			qry.setParameter("prgrmId", ScheduleId);
			qry.setParameter("sts","accepted");
			List<Application> applicationList =qry.getResultList();
			System.out.println("In DaoImpl getApplicationOnSheduledId applicationList:"+applicationList);
			return applicationList;
			
		
		} catch (Exception e) {
			throw new UniversityAdmissionException("Improper qry Fabrication",e);
		}
	}

	@Override
	public boolean updateApplicationDB(int id, String status)
			throws UniversityAdmissionException {
		System.out.println("in dao Impl updateApplicationDB" );
		System.out.println("Id (DaoImplUpdateapplicationDb):"+id);
		System.out.println("Status (DaoImplUpdateapplicationDb):"+status);
		
		Application app = new Application();
		app=manager.find(Application.class, id);
		app.setStatus(status);
		
		System.out.println("in Dao Impl:"+app);
		manager.merge(app);
		return true;
	}
}
