package com.capgemini.appl.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name = "Application")
@Table(name = "APPLICATION")
// //////////////////////////////////////////////////////////@NamedQuery
@NamedQueries({ @NamedQuery(name = "qryAllAppl", query = "select e from Application e"), 
	@NamedQuery(name = "qryAllApplApplied", query = "select e from Application e where e.status='applied'"),
	@NamedQuery(name = "qryAllApplId", query = "select a from Application a where scheduled.scheduledProgramId=:prgrmId "),
	@NamedQuery(name="qryAllAppDetail", query="select ap from Application ap where scheduled.scheduledProgramId=:prgrmId and status=:sts")
		
}
	
		)
// ///////////////
@SequenceGenerator(name = "appl_seq_generater", sequenceName = "application_id", allocationSize = 1, initialValue = 1)
public class Application {
	private int applicationId;
	private String fullName;
	private java.sql.Date dateOfBirth;
	private String highestQualification;
	private int marksObtained;
	private String goals;
	private String emailId;
	// private String Scheduled_program_id;
	private ProgramsScheduled scheduled;
	private String status;
	private java.sql.Date DateOfInterview;

	@Id
	@GeneratedValue(generator = "appl_seq_generater", strategy = GenerationType.SEQUENCE)
	@Column(name = "Application_id")
	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	@Size(max = 40, min = 1, message = "Please Enter Valid Name")
	@NotEmpty(message = "name is required")
	@Column(name = "full_name")
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Past(message = "date of birth should be less than todays date")
	@Column(name = "date_of_birth")
	public java.sql.Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(java.sql.Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@NotEmpty(message = "Qualification is required")
	@Column(name = "highest_qualification")
	public String getHighestQualification() {
		return highestQualification;
	}

	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}

	//@Size(min = 40, max = 100, message = "Minimum 40% is required")
	@Column(name = "marks_obtained")
	public int getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(int marksObtained) {
		this.marksObtained = marksObtained;
	}

	@NotEmpty(message = "Goal should not be empty")
	@Column(name = "goals")
	public String getGoals() {
		return goals;
	}

	public void setGoals(String goals) {
		this.goals = goals;
	}

	@NotEmpty(message="Email should not be empty")
	@Email(message = "please Enter valid email")
	@Column(name = "email_id")
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/*
	 * @NotEmpty(message="please Enter Schedule") public String
	 * getScheduled_program_id() { return Scheduled_program_id; } public void
	 * setScheduled_program_id(String scheduled_program_id) {
	 * Scheduled_program_id = scheduled_program_id; }
	 */

  //  @NotEmpty(message = "Enter status")
	@Column(name = "status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "Date_Of_Interview")
	public java.sql.Date getDateOfInterview() {
		return DateOfInterview;
	}

	public void setDateOfInterview(java.sql.Date dateOfInterview) {
		DateOfInterview = dateOfInterview;
	}

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Scheduled_program_id")
	public ProgramsScheduled getScheduled() {
		return scheduled;
	}

	public void setScheduled(ProgramsScheduled scheduled) {
		this.scheduled = scheduled;
	}

	@Override
	public String toString() {
		return "Application [applicationId=" + applicationId + ", fullName="
				+ fullName + ", dateOfBirth=" + dateOfBirth
				+ ", highestQualification=" + highestQualification
				+ ", marksObtained=" + marksObtained + ", goals=" + goals
				+ ", emailId=" + emailId + ", scheduled=" + scheduled
				+ ", status=" + status + ", DateOfInterview=" + DateOfInterview
				+ "]";
	}
}
